#!/usr/bin/env python3

STATUS_OK = 0
STATUS_ERR = -1

ENROLL_OK = "accepted."
ENROLL_ERR = "rejected."

AUTH_OK = "access granted."
AUTH_ERR = "access denied."
